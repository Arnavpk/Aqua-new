import { notFound } from 'next/navigation';
import { getLocation, getAllLocationSlugs } from '@/lib/locations';
import { getAllStrapiLocations } from '@/lib/strapi/getLocations';
import { getNavItems } from '@/lib/strapi/getNav';
import { MobileTabBar } from '@/components/MobileTabBar';
import { LocationPicker } from '@/components/LocationPicker';

export function generateStaticParams() {
  return getAllLocationSlugs().map((slug) => ({ location: slug }));
}

export function generateMetadata({ params }) {
  const loc = getLocation(params.location);
  if (!loc) return {};
  return {
    title: `${loc.displayName} — India's Premier Water Park`,
    description: `${loc.displayName} — 14 signature rides, 3 pools. Book tickets from ${loc.pricing.currency}${loc.pricing.from}.`,
  };
}

export default async function LocationLayout({ children, params }) {
  if (!getLocation(params.location)) notFound();

  const strapiLocations = await getAllStrapiLocations();
  const navItems = await getNavItems(params.location);

  return (
    <>
      <LocationPicker locations={strapiLocations} currentSlug={params.location} />
      {/* Pass navItems and locations via data attributes or context */}
      <script
        id="nav-data"
        type="application/json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({ navItems, locations: strapiLocations }),
        }}
      />
      {children}
      <MobileTabBar locationSlug={params.location} />
    </>
  );
}